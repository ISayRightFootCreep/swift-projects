import SwiftUI
import Foundation

struct ContentView: View {
    @State var denary = 0
    @State var binary = ""
    
    func BinaryCalc() -> Int {
        while denary > 0 {
            binary = String(denary % 2) + binary
            denary = Int(denary / 2)
        }
    }
    
    var body: some View {
        VStack{
            Text("Binary number generator")
                .font(.title)
                .padding()
            HStack{
                Text("number: ")
                TextField("input", value: $denary, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .border(.black, width: 1)
            }
            HStack{
                Text("Binary:")
                    .font(.title)
                Text(String())
            }
        }
        
    }
}
            
